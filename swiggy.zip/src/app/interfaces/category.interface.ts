export interface Category {
    name: string,
    img: string
}
